/** Tarefa desenvolvida pela dupla :
Cristian Veggian Matias
Felipe Galvão Gregório
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct{
  char indice[4];
  char nome[26];
  char cidade[21];
  int rrn;
}DADOS;

void formataString(char *string, int size){
  for(int i = 0; i < size-1; i++){
    if(string[i] ==' ' && string[i+1] == ' '){
      string[i] = '\0';
      return;
    }
  }
  if(string[size-2]==' ' || string[size-2]=='\n')
    string[size-2]='\0';
}

int arrumaIndice(const void *X, const void *Y){
  int A = atoi((*(DADOS*)X).indice);
  int B = atoi((*(DADOS*)Y).indice);
  return ( A - B);
}//organiza vetor por índices 

int arrumaNome(const void *X, const void *Y){
  return (strcmp((*(DADOS*)X).nome, (*(DADOS*)Y).nome));
}//organiza vetor por nome

int arrumaCidade(const void *X, const void *Y){
  return (strcmp((*(DADOS*)X).cidade, (*(DADOS*)Y).cidade));
}//organiza vetor por cidade

void indicePrimario(FILE *saida){
  
  FILE *arq =  fopen("cadastro.txt", "r");
  if (arq == NULL){
    printf("Deu pau no arquivo de entrada!");
    exit(1);
  }

  DADOS data[500];

  for(int i = 0; i < 500; i++){
    fgets(data[i].indice, 4, arq);
    fseek(arq, 73, SEEK_CUR);
    data[i].rrn = i*76;
  }
  
  //organiza o arquivo por índice
  qsort(data, 500, sizeof(DADOS), arrumaIndice);

  for(int i = 0; i < 500; i++){
    fprintf(saida, "%s %i\n", data[i].indice,  data[i].rrn);
  }
  
  fclose(arq);
}//cria o arquivo de índice primario

void indiceNome(FILE *saida){
  FILE *arq =  fopen("cadastro.txt", "r");

  if (arq == NULL){
    printf("Deu pau no arquivo de entrada!");
    exit(1);
  }

  DADOS data[500];

  fseek(arq, 3, SEEK_SET);

  for(int i = 0; i < 500; i++){
    fgets(data[i].nome, 26, arq);
    fseek(arq, 51, SEEK_CUR);
    data[i].rrn = i*76;
  }

  //organiza o arquivo por nome
  qsort(data, 500, sizeof(DADOS), arrumaNome);

  for(int i = 0; i < 500; i++){
    fprintf(saida, "%s %i\n", data[i].nome,  data[i].rrn);
  }

  fclose(arq);
}// cria arquivo de índice secundário fracamente ligado

void indiceCidade(FILE *saida){
  
  FILE *arq =  fopen("cadastro.txt", "r");
  if (arq == NULL){
    printf("Deu pau no arquivo de entrada!");
    exit(1);
  }

  DADOS data[500];

  for(int i = 0; i < 500; i++){
    fgets(data[i].indice, 4, arq);
    fseek(arq, 50, SEEK_CUR);
    fgets(data[i].cidade, 21, arq);
    fseek(arq, 3, SEEK_CUR);
  }

  //organiza o arquivo por índice
  qsort(data, 500, sizeof(DADOS), arrumaCidade);

  for(int i = 0; i < 500; i++)
    fprintf(saida, "%s %s\n", data[i].cidade,  data[i].indice);

  fclose(arq);
}//cria arquivo secundario fracamente ligado com cidade

void listaTodos(FILE *nomes){

  FILE *arq =  fopen("cadastro.txt", "r");
  if (arq == NULL){
    printf("Deu pau no arquivo de entrada!");
    exit(1);
  }

  int rrn;
  char aux[76];

  fseek(nomes, 26, SEEK_SET);
  
  for(int i = 0; i < 500; i++){
    fscanf(nomes, "%i\n", &rrn);
    fseek(nomes, 26, SEEK_CUR);
    fseek(arq, rrn, SEEK_SET);
    fgets(aux, 76, arq);
    printf("%s\n", aux);
  }
}//lista todos os os arquivos do cadastro em ordem alfabética

void pesquisarNome(FILE *nomes){

  char nome[26];
  char aux[26];
  int posicaoAtual = 250;
  int posicaoAnterior = 500;
  int aux2;

  FILE *arq =  fopen("cadastro.txt", "r");
  if (arq == NULL){
    printf("Deu pau no arquivo de entrada!");
    exit(1);
  }

  printf("Insira o nome do seu amigo:");
  fgets(nome, 26, stdin);
  nome[strcspn(nome, "\n")]='\0';
  int contador = 0;

  do{
    contador = 0;

    fseek(nomes, 0, SEEK_SET);

    while(posicaoAtual - contador != 0){
      if(fgetc(nomes) == '\n'){
        contador++;
      }
    };

    fgets(aux, 26, nomes);
    
    if(memcmp(aux, nome, strlen(nome))==0){
      fscanf(nomes, "%i\n", &aux2);
      fseek(arq, aux2, SEEK_SET);
      fgets(aux, 76, arq);
      printf("Aqui está o seu amigo\n%s\n\n", aux);
      return; 
    }

    else if(memcmp(aux, nome, strlen(nome)) > 0){
      aux2 = posicaoAtual;
      if(posicaoAtual % 2 == 1)
        posicaoAtual++;
      posicaoAtual = abs((abs(posicaoAnterior - posicaoAtual)/2) - posicaoAtual);
      posicaoAnterior = aux2;
    }

    else {
      aux2 = posicaoAtual;
      if(posicaoAtual % 2 == 1)
        posicaoAtual++;
      posicaoAtual = abs(posicaoAnterior - posicaoAtual)/2 + posicaoAtual;
      posicaoAnterior = aux2;
    }

  }while(posicaoAtual != posicaoAnterior);

  printf("Nenhum amigo encontrado : (\n");
  fclose(arq);

}//pesquisa binária nome

void pesquisarCidade(FILE *cidades){

  char cidade[21];
  char aux[21];
  int posicaoAtual = 250;
  int posicaoAnterior = 500;
  int aux2;

  FILE *arq =  fopen("cadastro.txt", "r");
  if (arq == NULL){
    printf("Deu pau no arquivo de entrada!");
    exit(1);
  }

  FILE *arq2 =  fopen("indicePrimario.txt", "r");
  if (arq2 == NULL){
    printf("Deu pau no arquivo de entrada!");
    exit(1);
  }

  printf("Insira a cidade do seu amigo:");
  fgets(cidade, 21, stdin);
  cidade[strcspn(cidade, "\n")]='\0';
  int contador = 0;

  do{
    contador = 0;

    fseek(cidades, 0, SEEK_SET);

    while(posicaoAtual - contador != 0){
      if(fgetc(cidades) == '\n'){
        contador++;
      }
    };

    fgets(aux, 21, cidades);
    
    if(memcmp(aux, cidade, strlen(cidade))==0){
      fscanf(cidades, "%i\n", &aux2);
      fseek(arq, aux2, SEEK_SET);
      fgets(aux, 76, arq);
      printf("Aqui está o seu amigo\n%s\n\n", aux);
      return; 
    }

    else if(memcmp(aux, cidade, strlen(cidade)) > 0){
      aux2 = posicaoAtual;
      if(posicaoAtual % 2 == 1)
        posicaoAtual++;
      posicaoAtual = abs((abs(posicaoAnterior - posicaoAtual)/2) - posicaoAtual);
      posicaoAnterior = aux2;
    }

    else {
      aux2 = posicaoAtual;
      if(posicaoAtual % 2 == 1)
        posicaoAtual++;
      posicaoAtual = abs(posicaoAnterior - posicaoAtual)/2 + posicaoAtual;
      posicaoAnterior = aux2;
    }

  }while(posicaoAtual != posicaoAnterior);

  printf("Nenhuma cidade encontrads : (\n");
  fclose(arq);
}//pesquisa binaria cidade 

int main(void) {


  FILE *file_indice_primario = fopen("indicePrimario.txt", "w");
  if (file_indice_primario == NULL){
    printf("Deu pau no arquivo indicePrimario!");
    exit(1);
  }
  else if(feof(file_indice_primario) == 0){
    indicePrimario(file_indice_primario);
    fclose(file_indice_primario);
  }

  //################################################

  FILE *file_indice_nome = fopen("indiceNome.txt", "w");
  if (file_indice_nome == NULL){
    printf("Deu pau no arquivo indiceNome!");
    exit(1);
  }
  else if(feof(file_indice_nome) == 0){
    indiceNome(file_indice_nome);
    fclose(file_indice_nome);
  }

  //################################################

  FILE *file_indice_cidade = fopen("indiceCidade.txt", "w");
  if (file_indice_cidade == NULL){
    printf("Deu pau no arquivo indiceCidade!");
    exit(1);
  }
  else if(feof(file_indice_cidade) == 0){
    indiceCidade(file_indice_cidade);
    fclose(file_indice_cidade);
  }

  //################################################

  int opcao = 0;
  do{
    printf("==========Amigos do Apolônio==========\n");
    printf("1.Listar todos os dados dos amigos\n");
    printf("2.Pesquisar por Nome\n");
    printf("3.Pesquisar por Cidade\n");
    printf("4.Sair\n");
    printf("Digite sua opção:");
    scanf("%i", &opcao);
    setbuf(stdin, NULL);
    switch(opcao){
      case 1:
      {
        FILE *file_indice_nome = fopen("indiceNome.txt", "r");
          if (file_indice_nome == NULL){
            printf("Deu pau no arquivo indiceNome!");
            exit(1);
          }
        listaTodos(file_indice_nome);
        fclose(file_indice_nome);
        break;
        }
      case 2:
      {
        FILE *file_indice_nome = fopen("indiceNome.txt", "r");
        if (file_indice_nome == NULL){
          printf("Deu pau no arquivo indiceNome!");
          exit(1);
        }
        pesquisarNome(file_indice_nome);
        fclose(file_indice_nome);
        break;
      }
      case 3:
      {
        FILE *file_indice_cidade = fopen("indiceCidade.txt", "r");
        if (file_indice_cidade == NULL){
          printf("Deu pau no arquivo indiceCidade!");
          exit(1);
        }
        pesquisarCidade(file_indice_cidade);
        fclose(file_indice_cidade);
        break;
      }
      case 4:
        printf("Adiós, Apolônio\n");
        break;
      default:
        printf("Opção inválida!\n");
        break;
    }
  }while(opcao != 4);

  return 0;
}